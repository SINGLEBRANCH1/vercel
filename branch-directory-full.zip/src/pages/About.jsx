import React from 'react';

export default function About() {
  return (
    <div>
      <h1>About Us</h1>
      <p>Branch Directory helps connect people with trusted businesses and essential services.</p>
    </div>
  );
}