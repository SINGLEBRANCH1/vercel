import React from 'react';

export default function Contact() {
  return (
    <div>
      <h1>Contact Us</h1>
      <p>Email: support@branchdirectory.com (placeholder)</p>
      <p>Phone: (XXX) XXX-XXXX</p>
    </div>
  );
}