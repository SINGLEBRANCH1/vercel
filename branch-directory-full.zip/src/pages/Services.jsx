import React from 'react';

export default function Services() {
  return (
    <div>
      <h1>Our Services</h1>
      <ul>
        <li>Business Listings</li>
        <li>Foreclosure + Tax Overages Recovery Assistance</li>
        <li>Business Verification</li>
        <li>Lead Generation</li>
      </ul>
    </div>
  );
}