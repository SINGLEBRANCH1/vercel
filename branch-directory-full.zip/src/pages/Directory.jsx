import React from 'react';

export default function Directory() {
  return (
    <div>
      <h1>Business Directory</h1>
      <p>This page will display business listings. We can later add search, filters, and categories.</p>
    </div>
  );
}