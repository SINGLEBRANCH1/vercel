import React from 'react';

export default function Home() {
  return (
    <div>
      <h1>Branch Directory</h1>
      <p>Your central hub for business listings and services.</p>
    </div>
  );
}